# Aether One AI – TrustCore v1.0

Puhdas C-toteutus Lex Resiliens -säännöstöstä (LR-IRS, LR-RAP, LR-R, LR-E, LR-D).

Tiedostot:
- `trustcore.h` – julkinen rajapinta (tyypit ja funktiot)
- `trustcore.c` – ydinlogiikka (KRI-laskenta ja LR-D-dissonanssifiltteri)

Tavoite:
Luoda alustariippumaton ydin, joka voidaan portata RISC-V-, ARM- tai x86-ympäristöön
ilman muutoksia. Ihminen säilyy aina päätöksentekijänä; TrustCore antaa vain
rakenteellisen ja eettisen analyysin.

Motto:
> "Aether speaks last – and only truthfully."
