# AetherNet Relay v1.3 - TrustCore Dynamic Resilience API
# Python/FastAPI-toteutus TrustCore v1.3 -logiikasta.

from enum import Enum
from typing import List
from datetime import datetime
from fastapi import FastAPI
from pydantic import BaseModel, Field

class AlertMode(str, Enum):
    NONE = "NONE"
    PREALERT = "PREALERT"
    CRISIS = "CRISIS"

class AdaptFocus(str, Enum):
    NONE = "NONE"
    RESOURCES = "RESOURCES"
    SOCIAL = "SOCIAL"
    ECO = "ECO"

class PSARecord(BaseModel):
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    region_id: str
    scenario_id: str
    R_avg: float = Field(..., ge=0, le=1)
    S_avg: float = Field(..., ge=0, le=1)
    E_avg: float = Field(..., ge=0, le=1)
    kri_x: float = Field(..., ge=0, le=1)
    delta_s: float = Field(..., ge=0, le=1)
    irs_rap_ok: int = Field(..., ge=0, le=1)
    psa: float = Field(..., ge=0, le=1)
    alert_flag: int = Field(..., ge=0, le=1)
    psa_prev: float = Field(..., ge=0, le=1)
    sigmaS: float = Field(..., ge=0, le=1)

def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))

def calculate_kri_x_momentum(psa_current: float, psa_prev: float, sigmaS: float) -> float:
    psa_current = clamp(psa_current, 0.0, 1.0)
    sigmaS = clamp(sigmaS, 0.0, 1.0)
    drift = psa_current - psa_prev
    gain = 2.0
    drift_factor = clamp(drift * gain, -0.3, 0.3)
    base = psa_current * (1.0 - sigmaS)
    kri_x = base * (1.0 + drift_factor)
    return clamp(kri_x, 0.0, 1.0)

def aac_evaluate(kri_x_momentum: float, alert_flag_raw: int) -> AlertMode:
    if alert_flag_raw == 1:
        return AlertMode.CRISIS
    if kri_x_momentum < 0.60:
        return AlertMode.PREALERT
    return AlertMode.NONE

def aac_suggest_focus(R_avg: float, S_avg: float, E_avg: float, delta_S: float) -> AdaptFocus:
    min_val = R_avg
    focus = AdaptFocus.RESOURCES
    if S_avg < min_val:
        min_val = S_avg
        focus = AdaptFocus.SOCIAL
    if E_avg < min_val:
        min_val = E_avg
        focus = AdaptFocus.ECO
    if R_avg > 0.7 and S_avg > 0.7 and E_avg > 0.7:
        if delta_S > 0.2:
            return AdaptFocus.SOCIAL
        return AdaptFocus.NONE
    return focus

def ler_global_lockdown(node_records: List[PSARecord], threshold_ratio: float = 0.30) -> bool:
    if not node_records:
        return False
    total_nodes = len(node_records)
    broken_nodes = sum(1 for n in node_records if n.irs_rap_ok == 0)
    ratio = broken_nodes / total_nodes
    return ratio >= threshold_ratio

app = FastAPI(title="AetherNet TrustCore v1.3 Relay API", description="Dynamic resilience engine")

class NodeAnalysisRequest(BaseModel):
    R_avg: float
    S_avg: float
    E_avg: float
    delta_s: float
    psa_current: float
    psa_prev: float
    sigmaS: float
    alert_flag: int

class NodeAnalysisResponse(BaseModel):
    kri_x_momentum: float
    alert_mode: AlertMode
    adapt_focus: AdaptFocus

@app.post("/analyze_node_resilience", response_model=NodeAnalysisResponse)
async def analyze_node_resilience(req: NodeAnalysisRequest):
    kri_x_momentum = calculate_kri_x_momentum(req.psa_current, req.psa_prev, req.sigmaS)
    alert_mode = aac_evaluate(kri_x_momentum, req.alert_flag)
    adapt_focus = aac_suggest_focus(req.R_avg, req.S_avg, req.E_avg, req.delta_s)
    return NodeAnalysisResponse(kri_x_momentum=kri_x_momentum, alert_mode=alert_mode, adapt_focus=adapt_focus)

class GlobalLERRequest(BaseModel):
    nodes: List[PSARecord]
    threshold_ratio: float = 0.30

class GlobalLERResponse(BaseModel):
    is_lockdown_triggered: bool

@app.post("/global_ler_check", response_model=GlobalLERResponse)
async def global_ler_check(req: GlobalLERRequest):
    result = ler_global_lockdown(req.nodes, req.threshold_ratio)
    return GlobalLERResponse(is_lockdown_triggered=result)
