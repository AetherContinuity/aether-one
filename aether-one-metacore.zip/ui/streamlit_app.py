"""Aether One – Kuopio Core Console (Streamlit demo)."""

import sys
from pathlib import Path

import streamlit as st

# Lisää src/ polkuun, jotta aether_core löytyy
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from aether_core.lr_engine import LREngine, LRResult
from aether_core.moods import interpret_overall


def call_llm(user_text: str, mode: str) -> str:
    """Paikka oikealle LLM-kutsulle.

    Tässä demossa palautetaan vain kevyt tulkinta käyttäjän tekstistä.
    Myöhemmin tähän voi liittää GPT/Claude/Gemini-kutsun.
    """
    core_values = (
        "Truth before comfort; Freedom without ownership; "
        "Honesty without display; Responsibility without reward."
    )
    return (
        "Aether LLM-tulkinta (demo):\n"
        f"{user_text}\n\n"
        "Lyhyesti: tämä malli pyrkii vahvistamaan paikallista resilienssiä "
        "yhdistämällä rakenteellisen, sosiaalisen ja ekologisen kestävyyden.\n"
        f"(Mood: {mode}, Core values: {core_values})"
    )


def main() -> None:
    st.set_page_config(page_title="Aether One – Kuopio Core Console", layout="wide")
    st.title("Aether One AI – Kuopio Core Console (v0.3 demo)")
    st.write("Kirjoita suunnitelma / päätös ja arvioidaan se LR()-resilienssikehikolla.")

    col1, col2 = st.columns(2)

    with col1:
        text = st.text_area(
            "Kuvaile suunnitelma, hanke tai päätös (esim. Lex Tieresiliens -malli)",
            height=220,
        )
        mode = st.radio(
            "Valitse Aether-moodi",
            options=["KuopioCore", "ENGINEER", "PHILO", "LEX"],
            index=0,
        )
        run = st.button("Arvioi LR():llä")

    with col2:
        if run and text.strip():
            # 1) LLM-vastaus (tässä demossa dummy)
            model_answer = call_llm(text, mode)

            # 2) LR()-arvio vastauksesta
            lr = LREngine.from_text(model_answer)
            overall = interpret_overall(mode, lr)

            st.subheader("Aether-vastaus")

            st.markdown("**Vastaus (LLM/dummy):**")
            st.write(model_answer)

            st.markdown("**LR():**")
            st.write(f"- R (rakenteellinen): {lr.R:.2f}")
            st.write(f"- S (sosiaalinen): {lr.S:.2f}")
            st.write(f"- E (ekologinen): {lr.E:.2f}")
            st.write(f"- KRI_X: {lr.kri_x:.2f} – {lr.verdict}")

            st.markdown("**Moodikohtainen tulkinta:**")
            st.write(overall)

            low_dims = [name for name, v in [("R", lr.R), ("S", lr.S), ("E", lr.E)] if v < 0.6]
            if low_dims:
                st.markdown("**Aether Note:**")
                st.write(
                    "Yksi tai useampi resilienssidimensio on heikko "
                    f"(heikko taso: {', '.join(low_dims)}). "
                    "Suosittelen palaamaan suunnitelmaan ja vahvistamaan tätä osa-aluetta."
                )
        elif run:
            st.info("Kirjoita ensin jotain arvioitavaksi.")


if __name__ == "__main__":
    main()
