from dataclasses import dataclass


@dataclass
class LRResult:
    """LR() tulos: R, S, E ja yhdistetty KRI_X."""
    R: float
    S: float
    E: float
    kri_x: float
    verdict: str


class LREngine:
    """Yksinkertainen LR()-moottori v0.3.

    - from_manual: suora numeerinen syöttö
    - from_text: karkea heuristinen arvio tekstistä

    Myöhemmissä versioissa from_text voidaan korvata LLM-avusteisella analyysilla.
    """

    @staticmethod
    def from_manual(R: float, S: float, E: float) -> LRResult:
        """Suora LR()-arvio valmiilla arvoilla (0.0–1.0)."""
        kri = round((R + S + E) / 3, 3)
        if kri >= 0.8:
            verdict = "korkea resilienssi"
        elif kri >= 0.6:
            verdict = "keskitasoinen resilienssi"
        else:
            verdict = "heikko resilienssi"
        return LRResult(R=R, S=S, E=E, kri_x=kri, verdict=verdict)

    @staticmethod
    def from_text(text: str) -> LRResult:
        """Hyvin karkea tekstipohjainen LR()-arvio.

        Tämä on v0.3-heuristiikka: etsi avainsanoja rakenteesta, yhteisöstä ja ekologiasta.
        Tarkoitus on toimia prototyyppinä, ei lopullisena mallina.
        """
        lower = text.lower()

        # Rakenteellinen R
        r_score = 0.4
        if any(w in lower for w in ["suunnitelma", "budjetti", "vaihe", "aikataulu", "järjestelmä", "malli"]):
            r_score += 0.2
        if any(w in lower for w in ["riski", "risk", "huoltovarmuus", "redundanssi"]):
            r_score += 0.2
        if any(w in lower for w in ["pitkäjänteinen", "kestävä", "vakaa"]):
            r_score += 0.1

        # Sosiaalinen S
        s_score = 0.4
        if any(w in lower for w in ["ihminen", "asukkaat", "kylä", "yhteisö", "osuuskunta"]):
            s_score += 0.2
        if any(w in lower for w in ["reilu", "tasapuolinen", "oikeudenmukainen"]):
            s_score += 0.2
        if any(w in lower for w in ["vastuu", "avoimuus", "läpinäkyvä"]):
            s_score += 0.1

        # Ekologinen E
        e_score = 0.4
        if any(w in lower for w in ["biokaasu", "uusiutuva", "päästö", "co2", "hiilineutraali"]):
            e_score += 0.3
        if any(w in lower for w in ["luonto", "ympäristö", "ekologia", "kestävyys"]):
            e_score += 0.2

        # rajataan 0.0–1.0
        r_score = max(0.0, min(1.0, r_score))
        s_score = max(0.0, min(1.0, s_score))
        e_score = max(0.0, min(1.0, e_score))

        return LREngine.from_manual(r_score, s_score, e_score)
