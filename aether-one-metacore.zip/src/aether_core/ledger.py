"""Resilience Ledger v0.1 – yksinkertainen JSONL-loki."""

import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

LEDGER_FILE = Path("aether_ledger.jsonl")


def append_to_ledger(entry: Dict[str, Any]) -> None:
    """Tallentaa yhden merkinnän JSONL-muodossa."""
    entry_with_ts = {
        "timestamp": datetime.utcnow().isoformat(),
        **entry,
    }
    with LEDGER_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry_with_ts, ensure_ascii=False) + "\n")
