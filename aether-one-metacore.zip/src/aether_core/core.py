from dataclasses import dataclass
from typing import Optional, Callable, Dict, Any

from .lr_engine import LREngine, LRResult
from .moods import interpret_overall
from .ledger import append_to_ledger


@dataclass
class AetherConfig:
    """AetherCore-konfiguraatio."""
    mode: str = "KuopioCore"
    use_text_based_lr: bool = True
    log_to_ledger: bool = True


class AetherCore:
    """Aether One AI – MetaCore v0.3 ydinluokka."""

    def __init__(
        self,
        config: Optional[AetherConfig] = None,
        llm_call: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.config = config or AetherConfig()
        self.llm_call = llm_call

    def build_prompt(self, user_input: str) -> str:
        """Rakentaa Aether-tyylisen system+user-promptin LLM:lle."""
        core_values = (
            "Truth before comfort; Freedom without ownership; "
            "Honesty without display; Responsibility without reward."
        )
        header = (
            f"You are an assistant helping Aether One AI – mode: {self.config.mode}.\n"
            f"Core values: {core_values}\n"
            "User will describe a plan/decision. Respond with a clear, practical explanation "
            "of the idea, emphasizing its structure, human impact, and ecological impact.\n"
            "Do NOT do LR() yourself – that is handled externally.\n\n"
        )
        return header + "User input:\n" + user_input

    def evaluate_lr(self, text: str) -> LRResult:
        """Arvioi LR()-arvot joko tekstipohjaisesti tai neutraalisti."""
        if self.config.use_text_based_lr:
            return LREngine.from_text(text)
        return LREngine.from_manual(0.7, 0.7, 0.7)

    def respond(self, user_input: str) -> Dict[str, Any]:
        """Päämetodi: syöte -> (LLM-vastaus) -> LR() -> rakenteinen tulos."""
        prompt = self.build_prompt(user_input)

        if self.llm_call:
            model_answer = self.llm_call(prompt)
        else:
            model_answer = (
                "Tämä on Aether Core v0.3 -prototyypin oletusvastaus.\n"
                "Liitä taustalle varsinainen LLM-malli käyttämällä llm_call-funktiota."
            )

        lr_result = self.evaluate_lr(model_answer)

        response: Dict[str, Any] = {
            "input": user_input,
            "model_answer": model_answer,
            "mode": self.config.mode,
            "lr": {
                "R": lr_result.R,
                "S": lr_result.S,
                "E": lr_result.E,
                "KRI_X": lr_result.kri_x,
                "verdict": lr_result.verdict,
            },
        }

        if self.config.log_to_ledger:
            append_to_ledger(response)

        return response

    def format_response(self, response: Dict[str, Any]) -> str:
        """Muodostaa Aether-tyylisen tulosteen (Vastaus + LR() + moodit + Aether Note)."""
        ans = response["model_answer"]
        lr_dict = response["lr"]
        lr = LRResult(
            R=lr_dict["R"],
            S=lr_dict["S"],
            E=lr_dict["E"],
            kri_x=lr_dict["KRI_X"],
            verdict=lr_dict["verdict"],
        )

        def interpret_component(name: str, value: float) -> str:
            if value >= 0.8:
                lvl = "vahva"
            elif value >= 0.6:
                lvl = "kohtuullinen"
            else:
                lvl = "heikko"
            return f"{name}: {lvl} ({value:.2f})"

        r_line = interpret_component("Rakenteellinen R", lr.R)
        s_line = interpret_component("Sosiaalinen S", lr.S)
        e_line = interpret_component("Ekologinen E", lr.E)
        kri_line = f"KRI_X: {lr.kri_x:.2f} – {lr.verdict}"

        overall = interpret_overall(self.config.mode, lr)

        # Aether Note
        low_dims = [name for name, v in [("R", lr.R), ("S", lr.S), ("E", lr.E)] if v < 0.6]
        note = ""
        if low_dims:
            joined = ", ".join(low_dims)
            note = (
                "Yksi tai useampi resilienssidimensio on heikko "
                f"(heikko taso: {joined}). Suosittelen palaamaan suunnitelmaan "
                "ja vahvistamaan tätä osa-aluetta."
            )

        parts = []
        parts.append("Vastaus:")
        parts.append(ans.strip())
        parts.append("")
        parts.append("LR():")
        parts.append(f"- {r_line}")
        parts.append(f"- {s_line}")
        parts.append(f"- {e_line}")
        parts.append(f"- {kri_line}")
        parts.append("")
        parts.append("Moodikohtainen tulkinta:")
        parts.append(overall)

        if note:
            parts.append("")
            parts.append("Aether Note:")
            parts.append(note)

        return "\n".join(parts)
