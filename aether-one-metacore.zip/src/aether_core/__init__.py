"""Aether One AI – MetaCore core package."""
from .lr_engine import LRResult, LREngine
from .core import AetherCore, AetherConfig
