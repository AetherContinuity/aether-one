from .lr_engine import LRResult


def interpret_overall(mode: str, lr: LRResult) -> str:
    """Moodikohtainen tulkinta LR()-arvoista.

    - ENGINEER: painottaa R:ää
    - PHILO: painottaa S/E:tä
    - LEX: painottaa legitimiteettiä
    - KuopioCore (oletus): tasapainoinen
    """
    Rv, Sv, Ev, kri = lr.R, lr.S, lr.E, lr.kri_x
    m = (mode or "KuopioCore").upper()

    if m == "ENGINEER":
        if Rv < 0.6:
            return ("ENGINEER-näkökulma: rakenteellinen R on heikko – "
                    "ratkaisu ei kestä käytännön kuormaa ilman lisävahvistusta.")
        if Rv >= 0.8 and kri >= 0.7:
            return ("ENGINEER-näkökulma: vahva tekninen perusta ja hyvä kokonaisresilienssi. "
                    "Toteutuskelpoinen, tarkista vielä S/E-yksityiskohdat.")
        return ("ENGINEER-näkökulma: teknisesti kohtuullinen, mutta parannusvaraa "
                "rakenteessa tai pitkäjänteisyydessä.")

    if m == "PHILO":
        if Sv < 0.6:
            return ("PHILO-näkökulma: sosiaalinen ulottuvuus on heikko – "
                    "tämä voi murentaa luottamusta tai olla epäoikeudenmukainen.")
        if Ev < 0.6:
            return ("PHILO-näkökulma: ekologinen ulottuvuus on heikko – "
                    "lyhyen aikavälin hyöty voi syödä tulevaisuuden mahdollisuuksia.")
        if kri >= 0.8:
            return ("PHILO-näkökulma: ratkaisu on tasapainossa ihmisten, rakenteen ja luonnon kanssa. "
                    "Moraalisesti puolustettavissa.")
        return ("PHILO-näkökulma: ei katastrofi, mutta arvojen ja pitkän aikavälin "
                "merkityksen näkökulmasta suunnitelmaa kannattaa vielä syventää.")

    if m == "LEX":
        if Rv < 0.6:
            return ("LEX-näkökulma: juridinen tai rakenteellinen perusta on heikko – "
                    "päätös ei täytä kestävän hallinnon kriteerejä. Lex Lock Alert ⚠️")
        if Sv < 0.6:
            return ("LEX-näkökulma: sosiaalinen oikeudenmukaisuus vaarassa – "
                    "päätös voi menettää legitimiteettinsä julkisuudessa. Lex Lock Alert ⚠️")
        if Ev < 0.6:
            return ("LEX-näkökulma: ekologinen tai taloudellinen vastuu puutteellinen – "
                    "saattaa rikkoa resilienssinormeja. Lex Lock Alert ⚠️")
        if kri >= 0.8:
            return ("LEX-näkökulma: päätös on rakenteellisesti ja eettisesti kestävä, "
                    "soveltuu resilienssilainsäädännön malliksi.")
        return ("LEX-näkökulma: keskitason resilienssi – päätös on hyväksyttävissä, "
                "mutta perusteluja kannattaa vahvistaa.")

    # KuopioCore oletuksena
    if kri >= 0.8:
        return ("KuopioCore: korkea kokonaisresilienssi – R, S ja E ovat hyvässä tasapainossa.")
    if kri >= 0.6:
        return ("KuopioCore: keskitasoinen resilienssi – yksi tai useampi ulottuvuus "
                "kaipaa vahvistusta.")
    return ("KuopioCore: heikko kokonaisresilienssi – ratkaisu ei ole "
            "pitkällä aikavälillä kestävä ilman merkittävää korjausta.")
