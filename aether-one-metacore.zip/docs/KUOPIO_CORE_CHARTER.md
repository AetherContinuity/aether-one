# Aether One AI – Kuopio Core Live Instance Charter

(lyhennetty versio – varsinainen charter on keskustelussa, tämä placeholder
riittää paketin esittelyyn.)
