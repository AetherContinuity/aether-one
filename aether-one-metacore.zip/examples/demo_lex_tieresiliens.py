from aether_core.core import AetherCore, AetherConfig


def dummy_llm(prompt: str) -> str:
    return (
        "Suunnitelma: muodostetaan paikallinen tieosuuskunta, joka käyttää biokaasua ja paikallista kalustoa.\n"
        "Tavoite on vähentää kustannuksia, lisätä huoltovarmuutta ja pienentää CO2-päästöjä.\n"
        "Malli perustuu yhteisöön, osuuskuntavastuuseen ja uusiutuvaan energiaan."
    )


if __name__ == "__main__":
    cfg = AetherConfig(mode="KuopioCore", use_text_based_lr=True, log_to_ledger=False)
    core = AetherCore(config=cfg, llm_call=dummy_llm)

    user_text = (
        "Arvioi Lex Tieresiliens -mallia: paikallinen tieosuuskunta, "
        "biokaasulaitos, kustannusten leikkaus ja huoltovarmuus."
    )

    result = core.respond(user_text)
    print(core.format_response(result))
