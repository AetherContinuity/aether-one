from aether_core.lr_engine import LREngine


def test_from_manual_basic():
    res = LREngine.from_manual(0.8, 0.8, 0.8)
    assert res.kri_x == 0.8
    assert "resilienssi" in res.verdict
