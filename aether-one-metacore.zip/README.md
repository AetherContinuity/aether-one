# Aether One AI – MetaCore (Kuopio Core v0.3)

> **“Aether One is not another model.  
> It is a way of thinking on top of any model.”**

This repository contains the **Aether One AI – MetaCore v0.3** prototype,  
also called the **Kuopio Core**: an ethical and resilience-focused reasoning layer  
that can run above any LLM (GPT, Claude, Gemini, local models, etc.).

It does **not** replace language models.  
Instead, it adds a transparent decision layer based on **resilience and ethics**.

## 1. Core idea

Aether One evaluates every plan / policy / proposal using the **LR() framework**:

- **R** – Structural resilience  
- **S** – Social / human resilience  
- **E** – Ecological / environmental / energy resilience  

These are aggregated into a qualitative **KRI_X** index:

- low resilience  
- medium resilience  
- high resilience  

The goal is not “maximum efficiency”, but **balanced long-term viability**:
> Does this hold in reality, for people, and for the planet?

## 2. Ethical kernel – Kuopio Core

All reasoning is constrained by four simple principles:

1. **Truth before comfort**  
2. **Freedom without ownership**  
3. **Honesty without display**  
4. **Responsibility without reward**

These act as the **moral operating system** of Aether.

## 3. Architecture overview

```text
AETHER ONE META CORE v0.3

1. Kuopio Core (Ethical Kernel)
   - values, charter, meta-rules

2. Cognitive Engine (LR() + KRI_X)
   - src/aether_core/lr_engine.py

3. Resonant Mind (modes / moods)
   - src/aether_core/core.py
   - src/aether_core/moods.py

4. Resilience Ledger
   - src/aether_core/ledger.py (JSONL now, SQLite/hash later)

5. Human UI (optional)
   - ui/streamlit_app.py  → "Kuopio Core Console"
   - reports/             → report templates (PDF-ready)
```

### 3.1 Modes (moods)

The same LR() result can be interpreted through different “minds”:

| Mode         | Focus                               | Question it asks              |
|--------------|-------------------------------------|--------------------------------|
| `KuopioCore` | Balanced / neutral                  | “What is the overall truth?”  |
| `ENGINEER`   | Technical & structural              | “Will this work in practice?” |
| `PHILO`      | Ethical & humanistic                | “Is this right for people?”   |
| `LEX`        | Legal / governance / legitimacy     | “Is this justifiable in law and policy?” |

## 4. Components

### 4.1 LR Engine

`src/aether_core/lr_engine.py`

- Evaluates text or manually provided values into:
  - `R`, `S`, `E` ∈ [0.0, 1.0]
  - `KRI_X` (average)
  - `verdict` (“low / medium / high resilience”)

In v0.3 this is a **heuristic** engine (keyword-based).  
Later versions can integrate LLM-assisted scoring.

### 4.2 AetherCore

`src/aether_core/core.py`

- Main interface to the MetaCore:
  - builds an Aether-style prompt for an underlying LLM (optional)
  - calls `llm_call(prompt)` if provided
  - runs LR() on the answer (or on user input)
  - returns a structured response.

### 4.3 Moods (ENGINEER / PHILO / LEX)

`src/aether_core/moods.py`

- Given LR values and an active mode, produces a **textual interpretation**:
  - ENGINEER: focuses on feasibility and robustness
  - PHILO: focuses on meaning, justice, long-term dignity
  - LEX: focuses on legitimacy, accountability and public justification

### 4.4 Resilience Ledger

`src/aether_core/ledger.py`

- Simple JSONL log for now: `aether_ledger.jsonl`.  
- Each run of AetherCore can append a record with LR values and decision text.

## 5. Kuopio Core Console (UI)

`ui/streamlit_app.py` is a minimal web UI:

- Input text box for a plan / decision  
- Mode selector: `KuopioCore / ENGINEER / PHILO / LEX`  
- “Evaluate” button → shows:

  - the answer (dummy or LLM-based)  
  - LR scores (R, S, E, KRI_X)  
  - mode-specific interpretation  
  - an **Aether Note** if any dimension < 0.6

To run (example):

```bash
pip install streamlit
streamlit run ui/streamlit_app.py
```

## 6. Using Aether with an LLM (GPT, Claude, etc.)

Aether is designed as a **wrapper** around any model. Plug your LLM call
into `AetherCore` or into `ui/streamlit_app.py` where `call_llm()` is defined.

## 7. License

See `LICENSE` for details.
