
# Aether One Ledger (v0.4)
# Adds self-awareness metadata field

import json
from datetime import datetime

def log_entry(data, file_path="ledger.jsonl"):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "data": data,
        "self_awareness": "partial knowledge – human validation required"
    }
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
