
# Aether One AI – Kuopio Core v0.4
## Self-Aware Resilience Layer

### Overview
This version adds a **self-awareness meta-layer** to all LR() evaluations.
After each resilience analysis, Aether explicitly reminds the user:

> "Tämä arvio perustuu rajalliseen tietoon ja kontekstiin. Aether ei voi tietää, onko tämä ratkaisu todella reilu tai kestävä, mutta se voi näyttää, millä tavoin eri osapuolet voisivat sen nähdä."

### Files
- core.py — updated LR() function with self-awareness comment
- ledger.py — logs entries including `self_awareness` field
- README.md — version summary

### Motto
> "Aether speaks last – and only truthfully."
