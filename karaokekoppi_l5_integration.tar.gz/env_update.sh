#!/bin/bash
# .env päivitys FMI Time-Lock varten

# Lisää tämä rivi .env-tiedostoon:

FMI_PLACES=Helsinki,Kuopio,Oulu,Rovaniemi

# SELITYS:
# ========
# - FMI ei vaadi API-avainta (julkinen WFS-rajapinta)
# - Monipiste-mittaus: katso 4 kaupunkia samanaikaisesti
# - Time-Lock lasketaan "worst 2 of 4" -logiikalla
# - Jos haluat lisätä paikkoja: FMI_PLACES=Helsinki,Tampere,Turku,Oulu,Rovaniemi,Ivalo

# Testaa että FMI toimii:
# python3 -c "from ssa.weather_fmi import calculate_time_lock; print(calculate_time_lock())"

# Odotettu tulos:
# {
#   'status': 'WEAK',
#   'time_p': 0.42,
#   'metrics': {'t_med': -8.5, 'w_med': 4.2},
#   'points': [...]
# }
