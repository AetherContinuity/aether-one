#!/usr/bin/env python3
"""
HUB Case Manager Integration Patch
Lisää tämä koodi Hub:n päälooppiin
"""

# ============================================
# LISÄÄ TÄMÄ hub/main.py ALKUUN (imports)
# ============================================

from app.case_manager import CaseManager

# Luo Case Manager (kerran, ohjelman alussa)
case_manager = CaseManager(debounce_seconds=600)  # Max 1 case / 10min

# ============================================
# LISÄÄ TÄMÄ KOHTAAN JOSSA SSA-SNAPSHOT ON LUETTU
# JA RESILIENCE INDEX ON LASKETTU
# ============================================

# Arvioi tarvitaanko uusi Case
triggered, case_id, reason = case_manager.evaluate({
    "resilience_index": resilience_index,
    "locks": snapshot.get("locks", {})
})

if triggered:
    print(f"[CASE] 🚨 Uusi case käynnistyi: {case_id} ({reason})")
    
    # Lähetä hälytys (esim. sähköposti)
    # send_email(
    #     subject=f"KRIISIHÄLYTYS: {case_id}",
    #     body=f"Resilienssi-indeksi: {resilience_index:.2f}\nSyy: {reason}"
    # )
    
    # TAI käynnistä LLM-analyysi
    # asyncio.create_task(trigger_auto_brief(snapshot, case_id))
else:
    print(f"[CASE] ✅ Ei eskalaatiota (index={resilience_index:.2f}, case={case_id or 'ei aktiivista'})")

# ============================================
# MITÄ TÄMÄ TEKEE:
# ============================================
"""
TILANNE 1: Indeksi putoaa 0.92 → 0.84 (delta = 0.08)
  → triggered=True, case_id="CASE-1738245932", reason="INDEX_DROP_0.08"
  → Hälytys lähetetään

TILANNE 2: Time Lock muuttuu CRITICAL
  → triggered=True, reason="LOCK_CRITICAL"
  → Hälytys lähetetään

TILANNE 3: Indeksi vaihtelee 0.85 ↔ 0.87
  → triggered=False (delta < 0.07)
  → Ei turhaa hälyä

TILANNE 4: Indeksi putoaa taas 5 min päästä
  → triggered=False (debounce, max 1/10min)
  → Ei spämmiä
"""

# ============================================
# ANTI-FLAP PROTECTION:
# ============================================
"""
Case Manager muistaa:
- Viimeisimmän indeksin
- Viimeisimmän hälytyksen ajan
- Nykyisen case_id:n

Jos indeksi pomppii: 0.85 → 0.82 → 0.86 → 0.81
  → Vain ENSIMMÄINEN pudotus käynnistää casen
  → Seuraava case vasta 10 min kuluttua
"""
