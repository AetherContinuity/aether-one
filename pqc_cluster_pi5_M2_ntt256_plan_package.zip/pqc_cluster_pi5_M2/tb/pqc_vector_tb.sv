`timescale 1ns/1ps

// Vector-driven TB scaffold.
// This TB does NOT assume a specific top beyond a minimal interface.
// Adapt the UUT instance wiring to your current cluster/lane top.

module pqc_vector_tb;

  parameter int Q = 3329;
  parameter int COEFF_W = 16;
  parameter int N = 16;
  parameter int TW_WINDOW = 16;

  logic clk, reset;
  logic start;
  logic [7:0] stage_id;
  logic [7:0] stride, count;
  logic tw_in_valid;
  logic [$clog2(TW_WINDOW)-1:0] tw_in_idx;
  logic [COEFF_W-1:0] tw_in_data;
  logic cluster_done, cluster_error;

  // Example bases: lane0 and lane1. Adjust if your top differs.
  logic [14:0] base_addr_lane0, base_addr_lane1;

  // UUT (EDIT THIS to match your real top)
  // pqc_rvv_cluster_2lane uut ( ... );

  // Vectors
  logic [COEFF_W-1:0] inputs_mem [0:3*N-1]; // [a,b,tw] per case
  logic [COEFF_W-1:0] expect_mem [0:2*N-1]; // [ap,bp] per case

  // clock/reset
  always #5 clk = ~clk;
  initial begin
    clk = 0;
    reset = 1;
    #25 reset = 0;
  end

  // Load vectors
  initial begin
    $readmemh("vectors/inputs.memh", inputs_mem);
    $readmemh("vectors/expect.memh", expect_mem);
  end

  // Driver
  initial begin
    // defaults
    start = 0;
    stage_id = 0;
    stride = 8'd2;
    count  = N;
    base_addr_lane0 = '0;
    base_addr_lane1 = '0;
    tw_in_valid = 0;
    tw_in_idx = '0;
    tw_in_data = '0;

    @(negedge reset);

    // 1) preload memory (example shows direct hierarchical writes into banked_mem)
    //    Replace this with your preferred preload mechanism.
    //    Packing: lane0 uses case i => a,b at addresses (2*i, 2*i+1)
    //             lane1 uses case i => a,b at addresses (2*i+16, 2*i+17)
    for (int i = 0; i < N; i++) begin
      // lane0
      // uut.banked_mem[0][2*i]   = inputs_mem[3*i + 0];
      // uut.banked_mem[0][2*i+1] = inputs_mem[3*i + 1];
      // lane1 (example)
      // uut.banked_mem[0][2*i+16] = inputs_mem[3*i + 0];
      // uut.banked_mem[0][2*i+17] = inputs_mem[3*i + 1];
    end

    // 2) twiddle stream (use tw from vectors: inputs_mem[3*i+2])
    for (int i = 0; i < TW_WINDOW; i++) begin
      @(posedge clk);
      tw_in_valid <= 1;
      tw_in_idx   <= i[$clog2(TW_WINDOW)-1:0];
      tw_in_data  <= inputs_mem[3*i + 2];
    end
    @(posedge clk);
    tw_in_valid <= 0;

    // 3) kick
    @(posedge clk);
    start <= 1;
    @(posedge clk);
    start <= 0;

    // 4) wait
    @(posedge cluster_done);
    if (cluster_error) $fatal(1, "cluster_error asserted");

    // 5) check (example shows hierarchical reads)
    for (int i = 0; i < N; i++) begin
      logic [COEFF_W-1:0] exp_ap = expect_mem[2*i+0];
      logic [COEFF_W-1:0] exp_bp = expect_mem[2*i+1];

      // logic [COEFF_W-1:0] got_ap0 = uut.banked_mem[0][2*i];
      // logic [COEFF_W-1:0] got_bp0 = uut.banked_mem[0][2*i+1];

      // assert(got_ap0 == exp_ap) else $error("lane0 ap mismatch i=%0d got=%0d exp=%0d", i, got_ap0, exp_ap);
      // assert(got_bp0 == exp_bp) else $error("lane0 bp mismatch i=%0d got=%0d exp=%0d", i, got_bp0, exp_bp);
    end

    $display("✅ Vector TB completed (wire UUT + memory accesses to enable full checks).");
    $finish;
  end

endmodule
