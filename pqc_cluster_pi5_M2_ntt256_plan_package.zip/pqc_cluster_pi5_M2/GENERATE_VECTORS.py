#!/usr/bin/env python3
"""Generate test vectors for the PQC RVV banked cluster.

This generator is intentionally *small* and *deterministic* so it runs fast on
Raspberry Pi 5.

Outputs (under --out):
  - input_poly.memh   (256 words)  : input polynomial coefficients (0..Q-1)
  - expect_ntt.memh   (256 words)  : golden Kyber-style NTT result
  - twiddles.memh     (129 words)  : twiddles table (index 0 unused)

The NTT golden model matches the structure used in many Kyber RTL/firmware
implementations: Cooley–Tukey, in-place, using Montgomery reduction.
"""

import argparse
import random
from pathlib import Path

# Kyber parameters
Q = 3329
R = 1 << 16
# QINV = -q^{-1} mod 2^16 (Kyber reference commonly uses 62209)
QINV = 62209

# Kyber zetas (128 values) used by the NTT (bit-reversed / implementation order)
ZETAS_128 = [
    2285, 2571, 2970, 1812, 1493, 1422, 287, 202, 3158, 622, 1577, 182, 962, 2127, 1855, 1468,
    573, 2004, 264, 383, 2500, 1458, 311, 1530, 742, 2026, 1277, 1101, 1127, 726, 2781, 1038,
    1104, 273, 148, 3000, 2460, 470, 2205, 1392, 1390, 2111, 3236, 1434, 2453, 872, 2694, 1920,
    1479, 19, 1225, 43, 2758, 904, 2922, 1022, 2145, 1348, 1541, 1532, 156, 3179, 1062, 2854,
    283, 1352, 919, 3061, 2435, 2355, 3298, 2800, 2142, 2321, 1326, 2713, 1491, 1111, 2175, 2156,
    3115, 614, 2312, 2262, 2230, 1616, 267, 2287, 125, 2308, 650, 1526, 2885, 3161, 1148, 301,
    810, 2119, 1373, 1397, 2341, 285, 1258, 1235, 332, 2093, 188, 1885, 2722, 1485, 1427, 2090,
    1110, 2212, 1236, 1419, 1794, 2672, 3230, 2169, 438, 579, 3289, 1542, 2889, 3112, 1060, 1351,
]

# Implementation convenience: index 0 is unused, algorithm starts from k=1
ZETAS = [0] + ZETAS_128


def montgomery_reduce(a: int) -> int:
    """Montgomery reduction (16-bit R) used in Kyber-style implementations."""
    u = ((a & (R - 1)) * QINV) & (R - 1)
    t = (a + u * Q) >> 16
    # Bring to canonical representative [0, Q)
    if t >= Q:
        t -= Q
    return t


def ntt_256_golden(poly):
    """Kyber-style in-place 256-point NTT golden model."""
    if len(poly) != 256:
        raise ValueError("poly must have 256 coefficients")

    res = [x % Q for x in poly]
    k = 1
    # level 7 -> distance 128 ... level 0 -> distance 1
    for level in range(7, -1, -1):
        distance = 1 << level
        for start in range(0, 256, 2 * distance):
            zeta = ZETAS[k]
            k += 1
            for j in range(start, start + distance):
                t = montgomery_reduce(res[j + distance] * zeta)
                a_old = res[j]
                res[j] = (a_old + t) % Q
                res[j + distance] = (a_old - t) % Q
    return res


def write_memh(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for v in data:
            f.write(f"{int(v) & 0xFFFF:04x}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["ntt256"], default="ntt256")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="vectors")
    args = ap.parse_args()

    outdir = Path(args.out)
    outdir.mkdir(parents=True, exist_ok=True)

    random.seed(args.seed)

    if args.mode == "ntt256":
        # ---- Deterministic NTT execution plan (Single Source of Truth) ----
        # Stage s: distance = 1<<(7-s)  (128..1). We keep count=256 by default.
        plan = []
        for s in range(8):
            plan.append({
                "stage": s,
                "distance": 1 << (7 - s),
                "stride": 1 << (7 - s),
                "count": 256,
            })

        input_poly = [random.randint(0, Q-1) for _ in range(256)]
        output_poly = ntt_256(input_poly)

        write_memh(outdir / "input_poly.memh", input_poly)
        write_memh(outdir / "expect_ntt.memh", output_poly)
        write_memh(outdir / "twiddles.memh", ZETAS)

        # plan_ntt256.json for humans / tooling
        (outdir / "plan_ntt256.json").write_text(json.dumps({
            "q": Q,
            "mode": "ntt256",
            "seed": args.seed,
            "stages": plan
        }, indent=2))

        # plan_ntt256.memh for SystemVerilog TB (packed: [15:8]=stride, [7:0]=count)
        packed = [((p["stride"] & 0xFF) << 8) | (p["count"] & 0xFF) for p in plan]
        write_memh(outdir / "plan_ntt256.memh", packed)

        print(f"[OK] Generated NTT256 vectors + plan into: {outdir.resolve()}")
        return
        print("     - input_poly.memh (256)")
        print("     - expect_ntt.memh (256)")
        print("     - twiddles.memh (129; index0 unused)")


if __name__ == "__main__":
    main()
