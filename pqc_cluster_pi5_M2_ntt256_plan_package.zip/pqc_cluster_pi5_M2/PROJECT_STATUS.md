# PROJECT_STATUS.md — PQC RVV Banked Cluster

**Current Phase:** Phase 1 – RTL Prototype & Conflict + NTT Validation  
**Platform:** Raspberry Pi 5 (Simulation Host)  
**Parent Project:** Aether One™ / TrustCore NX Evolution  
**Last Updated:** 2026-02-09  

## 🟢 1. Current Progress (What Works)

### RTL Architecture
- [x] Modular Montgomery Multiplier: pipelined Z_q operations (baseline)
- [x] Banked Memory Subsystem: 4-bank scratchpad model for parallel access
- [x] Round-Robin Arbiter: deterministic per-bank conflict resolution logic
- [x] 2-Lane Cluster Top: lanes + crossbar + arbiter integrated into one unit

### Verification (Pi5 Simulation)
- [x] Icarus Verilog Flow: stable on ARM64 (Pi5)
- [x] Conflict Testbench: validates RR + stall behavior under forced bank conflicts
- [x] Waveform Trace: .vcd generation confirmed for GTKWave
- [x] Vector pipeline scaffolding: Python → .memh → SV TB integration

## 🟡 2. In Progress / Under Review
- [ ] **M2: Full 256-point NTT correctness** (Python golden vs RTL) — *in progress*
- [ ] Data mapping discipline: ensure stage-by-stage stride/permutation matches the RTL schedule
- [ ] Cycle model: tighten latency assumptions so ASIC projections stay honest

## 🔴 3. Immediate Technical Gaps (Next Hurdles)
- [ ] **NTT256 schedule integration:** define exact per-stage command fields (stride/count/base/twiddle schedule) that the RTL expects
- [ ] Performance counters:
  - total cycles per 256-pt NTT
  - total stall cycles due to bank conflicts
- [ ] 4-Lane expansion (post-M2): crossbar scaling + arbitration scaling

## 🚀 4. Roadmap to Silicon (Aether One Integration)

| Milestone | Objective | Target |
|---|---|---|
| M1 | 2-Lane deterministic cluster + conflict validation | DONE |
| **M2** | **Full 256-point NTT correctness on Pi5 sim** | Q1 2026 |
| M3 | FPGA prototype (e.g. Pynq-Z2 / Basys 3) | Q2 2026 |
| M4 | TrustCore NX integration (7nm target) | Q3 2026 |

## 🛠️ 5. Maintainer Notes (Marko)

> “Pi5 toimii täydellisenä hiekkalaatikkona. Kun banked-muistin hallinta ja NTT on täysin deterministinen täällä, sama logiikka siirtyy suoraan kalliimpaan ASIC-arkkitehtuuriin ilman yllätyksiä.”

## ✅ Session Checklist (Before You Code)

- [ ] `git status` is clean or changes are intentional
- [ ] `python3 GENERATE_VECTORS.py --mode ntt256 --seed 42 --out vectors` runs without errors
- [ ] `bash sim/verify_all.sh ntt256` runs and produces a PASS/FAIL summary
- [ ] If FAIL: open `gtkwave sim/pqc_ntt256_verified.vcd` and pinpoint the first mismatch stage

## 🔒 Status Locked & Saved
```bash
git add PROJECT_STATUS.md
git commit -m "Status: M2 NTT256 verification in progress"
```


## M2 Add-on: Data-driven NTT plan
- Python emits `vectors/plan_ntt256.json` + `vectors/plan_ntt256.memh` so TB and golden model cannot drift.
