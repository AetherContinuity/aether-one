# INSTALL (Raspberry Pi 5) — PQC Cluster Sim Stack

## 1) Packages
```bash
sudo apt-get update
sudo apt-get install -y iverilog gtkwave python3
```

## 2) Folder layout
Place your RTL under `rtl/`:
- `rtl/pqc_rvv_cluster_2lane.sv`
- `rtl/pqc_rvv_lane.sv`
- `rtl/montgomery_mul.sv`
- `rtl/pqc_bank_arbiter_rr.sv`
- `rtl/pqc_bank_crossbar.sv`

## 3) Generate vectors + run
```bash
./sim/run_vectors.sh simple 1 16
./sim/run_vectors.sh random 42 256
```

## 3b) Run the “highest judge” verified testbench
This is the strict, cycle-by-cycle protocol checker (stall + RR fairness) + data checker.

```bash
./sim/verify_all.sh
```

Outputs:
- `sim/verified_sim` (executable)
- `sim/pqc_verified.vcd` (GTKWave)

Outputs:
- `vectors/inputs.memh`
- `vectors/expect.memh`
- `vectors/meta.json`

## 4) What this validates
- Golden-model correctness of Montgomery mul + (a ± tw*b) mod q.
- Your RTL correctness once TB is wired to the real UUT + memory map.

Next: integrate a full 256-point NTT reference and compare stage-by-stage.
