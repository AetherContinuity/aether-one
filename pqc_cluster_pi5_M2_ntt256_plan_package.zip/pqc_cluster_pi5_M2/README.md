# PQC RVV Banked Cluster — Pi5 Simulation Harness

This is the **Raspberry Pi 5** sandbox for validating the **TrustCore NX** PQC compute cluster.

Focus:
- Deterministic banked SRAM behaviour (bank conflicts + stalls)
- Round-robin fairness under contention
- **Milestone M2:** 256-point Kyber-style NTT golden verification (Python vs RTL)

Start here:
- `INSTALL.md` — dependencies & how to run
- `PROJECT_STATUS.md` — current status + session ritual checklist
- `sim/verify_all.sh` — one-command pipeline

Quick run:
```bash
bash sim/verify_all.sh conflict   # conflict/stall fairness
bash sim/verify_all.sh ntt256     # milestone M2 (requires your RTL to support stage loop)
```
