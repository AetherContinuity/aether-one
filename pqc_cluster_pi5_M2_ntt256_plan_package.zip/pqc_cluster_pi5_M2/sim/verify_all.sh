#!/bin/bash
set -euo pipefail

MODE="${1:-conflict}"
SEED="${SEED:-42}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

mkdir -p sim vectors

echo "[1/3] Generating vectors (mode=$MODE, seed=$SEED) ..."
python3 GENERATE_VECTORS.py --mode "$MODE" --seed "$SEED" --out vectors

echo "[2/3] Compiling RTL + testbench ..."
# NOTE: place your SV sources under rtl/*.sv
if compgen -G "rtl/*.sv" > /dev/null; then
  RTL_SOURCES=(rtl/*.sv)
else
  echo "ERROR: rtl/*.sv not found. Place your SystemVerilog RTL files under ./rtl" >&2
  exit 2
fi

TB=""
DEFINES=()
case "$MODE" in
  conflict)
    TB="tb/pqc_cluster_verified_tb.sv"
    ;;
  ntt256)
    TB="tb/pqc_ntt256_verified_tb.sv"
    ;;
  simple)
    TB="tb/pqc_cluster_verified_tb.sv"
    ;;
  *)
    echo "Unknown mode: $MODE" >&2
    exit 2
    ;;
esac

iverilog -g2012 -o sim/verified_sim "${RTL_SOURCES[@]}" "$TB"

echo "[3/3] Running simulation ..."
vvp sim/verified_sim

echo "Done. If VCD was generated: gtkwave sim/*.vcd"
