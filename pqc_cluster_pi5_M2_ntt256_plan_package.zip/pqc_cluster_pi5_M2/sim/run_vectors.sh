#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./sim/run_vectors.sh [mode] [seed] [n]
# Example:
#   ./sim/run_vectors.sh random 42 256

MODE=${1:-simple}
SEED=${2:-1}
N=${3:-16}

ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
cd "$ROOT"

./GENERATE_VECTORS.py --mode "$MODE" --seed "$SEED" --n "$N" --out vectors

# EDIT: add your RTL files here
RTL_FILES=(
  rtl/pqc_rvv_cluster_2lane.sv
  rtl/pqc_rvv_lane.sv
  rtl/montgomery_mul.sv
  rtl/pqc_bank_arbiter_rr.sv
  rtl/pqc_bank_crossbar.sv
)

TB_FILES=(tb/pqc_vector_tb.sv)

iverilog -g2012 -o sim/out_vec "${RTL_FILES[@]}" "${TB_FILES[@]}"
vvp sim/out_vec

# Optional VCD: enable in TB with $dumpfile/$dumpvars if you want.
