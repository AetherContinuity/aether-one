# INSTALL.md — Pi5 Simulation Stack (PQC Cluster)

This repo is meant to be **the repeatable Pi5 simulation harness** for the TrustCore NX / Aether One PQC cluster work.

## 0) Requirements (Pi5 / Debian/Ubuntu)

```bash
sudo apt-get update
sudo apt-get install -y python3 python3-pip iverilog gtkwave make unzip
```

## 1) Repo layout

```
pqc_cluster_pi5_package/
  GENERATE_VECTORS.py
  rtl/                # <-- put your SystemVerilog RTL here
  tb/
    pqc_cluster_verified_tb.sv        # existing conflict/rr/stall judge
    pqc_ntt256_verified_tb.sv         # NTT256 “moment of truth” judge
  sim/
    verify_all.sh
  vectors/            # auto-generated
  PROJECT_STATUS.md
```

> **Important:** the package ships the *verification harness*, but your active RTL may live elsewhere.
> Copy/link your RTL files into `rtl/` so that `rtl/*.sv` contains at least:
> - `pqc_rvv_cluster_2lane.sv`
> - `pqc_rvv_lane.sv`
> - `pqc_bank_arbiter_rr.sv`
> - `pqc_bank_crossbar.sv`
> - `montgomery_mul.sv` (or equivalent)

## 2) Quick smoke: conflict + RR/stall validation

```bash
bash sim/verify_all.sh conflict
```
Artifacts:
- `sim/run.vcd` (open with GTKWave)

## 3) M2 milestone: full 256-point NTT verification

```bash
bash sim/verify_all.sh ntt256
```
Artifacts:
- `vectors/input_poly.memh`
- `vectors/expect_ntt.memh`
- `vectors/twiddles.memh`
- `sim/run.vcd`

## 4) GTKWave tips

```bash
gtkwave sim/run.vcd
```
Recommended signals (if present):
- `dut.req_rd*`, `dut.grant_rd*`, `dut.stall_*`
- lane FSM state(s): `dut.lane0.*`, `dut.lane1.*`

## 5) Checklist (session start ritual)

- [ ] `git status` clean / known changes
- [ ] `bash sim/verify_all.sh conflict` passes
- [ ] `bash sim/verify_all.sh ntt256` passes
- [ ] update `PROJECT_STATUS.md` (what changed, what is next)



## M2: NTT256 data-driven plan

`GENERATE_VECTORS.py --mode ntt256 --out vectors` now emits:
- `vectors/plan_ntt256.json` (human/tooling source of truth)
- `vectors/plan_ntt256.memh` (packed stage parameters for SV TB)

The TB will prefer `plan_ntt256.memh` if present, otherwise it falls back to the built-in stride model.
