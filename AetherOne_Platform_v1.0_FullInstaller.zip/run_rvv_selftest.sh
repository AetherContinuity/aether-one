#!/bin/bash
set -e
echo "=== Running Aether One RVV Self-Test ==="

if ! command -v riscv64-unknown-linux-gnu-gcc >/dev/null 2>&1; then
  echo "[ERROR] riscv64-unknown-linux-gnu-gcc not found in PATH."
  exit 1
fi

cat > test_rvv.c <<'EOF'
#include <stdio.h>
#include <riscv_vector.h>
int main() {
    size_t vl = vsetvl_e32m1(8);
    int32_t a_data[8] = {1,2,3,4,5,6,7,8};
    int32_t b_data[8] = {8,7,6,5,4,3,2,1};
    vint32m1_t a = vle32_v_i32m1(a_data, vl);
    vint32m1_t b = vle32_v_i32m1(b_data, vl);
    vint32m1_t c = vadd_vv_i32m1(a,b,vl);
    int32_t out[8];
    vse32_v_i32m1(out, c, vl);
    for (int i=0;i<8;i++) printf("%d ", out[i]);
    printf("\nRVV OK\n");
    return 0;
}
EOF

riscv64-unknown-linux-gnu-gcc -march=rv64gcv -mabi=lp64d -O2 test_rvv.c -o test_rvv
echo "[INFO] RVV test program compiled."
file test_rvv || true
echo "[NOTE] Running test_rvv requires RISC-V execution environment (emulator or target)."
echo "=== RVV Self-Test compilation completed ==="
