    #!/bin/bash
    set -e
    LOGFILE="/var/log/aether_pqc_benchmark.log"
    JSONFILE="/var/log/aether_pqc_benchmark.json"

    echo "=== Aether One PQC Benchmark (Post-Install) ===" | sudo tee "$LOGFILE"
    date | sudo tee -a "$LOGFILE"

    kyber_rvv_ms=0
    dil_rvv_ms=0
    kyber_ref_ms=0
    dil_ref_ms=0

    run_bench() {
      local alg="$1"
      local name="$2"
      local out_var="$3"

      echo -e "\n--- $name ---" | sudo tee -a "$LOGFILE"
      local start=$(date +%s%3N)
      openssl speed -evp "$alg" -seconds 3 > /tmp/aether_${name}.txt 2>&1 || true
      local end=$(date +%s%3N)
      local diff=$((end-start))
      grep -E "signs/s|ops/s" /tmp/aether_${name}.txt | sudo tee -a "$LOGFILE" || true
      eval "$out_var=$diff"
    }

    run_bench "kyber768:riscv_rvv" "Kyber768_RVV" kyber_rvv_ms
    run_bench "dilithium3:riscv_rvv" "Dilithium3_RVV" dil_rvv_ms
    run_bench "kyber768" "Kyber768_Ref" kyber_ref_ms
    run_bench "dilithium3" "Dilithium3_Ref" dil_ref_ms

    speedup_kyber=0
    speedup_dil=0

    if [ "$kyber_rvv_ms" -gt 0 ] && [ "$kyber_ref_ms" -gt 0 ]; then
      speedup_kyber=$(python3 - <<EOF
    print(round($kyber_ref_ms / $kyber_rvv_ms, 2))
EOF
)
    fi

    if [ "$dil_rvv_ms" -gt 0 ] && [ "$dil_ref_ms" -gt 0 ]; then
      speedup_dil=$(python3 - <<EOF
    print(round($dil_ref_ms / $dil_rvv_ms, 2))
EOF
)
    fi

    sudo bash -c "cat > $JSONFILE" <<EOF
{
  "timestamp": "$(date -Iseconds)",
  "device": "RaspberryPi5_or_TrustCoreNX_hosted",
  "kyber_rvv_ms": $kyber_rvv_ms,
  "kyber_ref_ms": $kyber_ref_ms,
  "dilithium_rvv_ms": $dil_rvv_ms,
  "dilithium_ref_ms": $dil_ref_ms,
  "speedup_kyber": $speedup_kyber,
  "speedup_dilithium": $speedup_dil
}
EOF

    echo "" | sudo tee -a "$LOGFILE"
    echo "✅ PQC benchmark complete. JSON saved to $JSONFILE" | sudo tee -a "$LOGFILE"
    cat "$JSONFILE"
