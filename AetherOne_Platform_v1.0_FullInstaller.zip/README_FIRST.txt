Aether One™ Platform v1.0 – Full Installer
=========================================
Target: Raspberry Pi 5 (64-bit Linux)
Install path: /opt/aetherone/

Quick start:
  1. Copy this ZIP to your Raspberry Pi 5.
  2. Unzip:
       unzip AetherOne_Platform_v1.0_FullInstaller.zip
  3. Run installer:
       cd aetherone_platform_v1.0
       bash install.sh

The installer will:
  - Install system dependencies (apt)
  - Create Python venv in /opt/aetherone/venv
  - Configure and build RVV-enabled RISC-V toolchain
  - Build and install liboqs (Kyber & Dilithium)
  - Run RVV self-test
  - Run PQC integration test
  - Run post-install PQC benchmark and write JSON to /var/log

After install, see docs/ for all technical PDFs.
