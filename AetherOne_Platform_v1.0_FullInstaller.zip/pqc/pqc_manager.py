"""Aether One – PQC Manager stub (Kyber/Dilithium via liboqs-python)"""
import oqs

DEFAULT_KEM = "Kyber768"

def generate_keys(algorithm: str = DEFAULT_KEM):
    kem = oqs.KeyEncapsulation(algorithm)
    pk = kem.generate_keypair()
    sk = kem.export_secret_key()
    kem.free()
    return pk, sk

def encapsulate(peer_pk: bytes, algorithm: str = DEFAULT_KEM):
    kem = oqs.KeyEncapsulation(algorithm)
    ct, ss = kem.encap_secret(peer_pk)
    kem.free()
    return ct, ss

def decapsulate(ct: bytes, sk: bytes, algorithm: str = DEFAULT_KEM):
    kem = oqs.KeyEncapsulation(algorithm)
    kem.import_secret_key(sk)
    ss = kem.decap_secret(ct)
    kem.free()
    return ss
