#!/bin/bash
set -e
echo "=== Installing liboqs and liboqs-python (PQC) ==="

sudo apt install -y git cmake ninja-build build-essential libssl-dev

WORKDIR="$HOME/vera_pqc"
mkdir -p "$WORKDIR"
cd "$WORKDIR"

if [ ! -d liboqs ]; then
  git clone https://github.com/open-quantum-safe/liboqs.git
fi
cd liboqs
mkdir -p build && cd build
cmake -GNinja .. -DOQS_USE_OPENSSL=ON -DCMAKE_INSTALL_PREFIX=/usr/local
ninja
sudo ninja install

cd "$WORKDIR"
if [ ! -d liboqs-python ]; then
  git clone https://github.com/open-quantum-safe/liboqs-python.git
fi
cd liboqs-python
export CFLAGS="-I/usr/local/include"
export LDFLAGS="-L/usr/local/lib"
pip install -U pip setuptools wheel
pip install .

echo "=== liboqs + liboqs-python installation complete ==="
