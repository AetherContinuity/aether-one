/* Stub for oqs_rvv OpenSSL provider.
 * In a full implementation this would bridge OpenSSL's provider API
 * to RVV-compiled liboqs Kyber/Dilithium primitives.
 */
