import oqs

def test_kem(algorithm):
    print(f"\n=== {algorithm} ===")
    with oqs.KeyEncapsulation(algorithm) as kem:
        pk = kem.generate_keypair()
        ciphertext, ss_s = kem.encap_secret(pk)
        ss_r = kem.decap_secret(ciphertext)
        print("Shared secret match:", ss_s == ss_r)

for algo in ["Kyber512", "Kyber768", "NTRU_HPS2048509"]:
    try:
        test_kem(algo)
    except Exception as e:
        print(f"[ERROR] {algo}: {e}")
