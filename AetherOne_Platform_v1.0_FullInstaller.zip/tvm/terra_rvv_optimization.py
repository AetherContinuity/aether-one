import tvm
from tvm import relay
from tvm.meta_schedule import tune_relay
from tvm.target import Target
import numpy as np
import os
import shutil

TRUSTCORE_NX_TARGET = Target(
    "llvm -mtriple=riscv64-unknown-linux-gnu -mcpu=generic-rv64 "
    "-mabi=lp64d -mattr=+v,+zfh"
)

INPUT_NAME = "data"
INPUT_SHAPE = (1, 4)
INPUT_DTYPE = "float32"
WORK_DIR = "terra_rvv_optimization_logs"

def create_simulated_terra_model():
    w = relay.var("w", shape=(4, 4), dtype=INPUT_DTYPE)
    data = relay.var(INPUT_NAME, shape=INPUT_SHAPE, dtype=INPUT_DTYPE)
    dense_output = relay.nn.dense(data, w)
    output = relay.nn.relu(dense_output)
    func = relay.Function([data, w], output)
    mod = tvm.IRModule.from_expr(func)
    params = { "w": tvm.nd.array(np.random.rand(4, 4).astype(INPUT_DTYPE)) }
    return mod, params

def optimize_terra_rvv():
    if os.path.exists(WORK_DIR):
        shutil.rmtree(WORK_DIR)
    mod, params = create_simulated_terra_model()
    print(f"Starting MetaSchedule RVV optimization for target: {TRUSTCORE_NX_TARGET}")
    database = tune_relay(
        mod=mod,
        params=params,
        target=TRUSTCORE_NX_TARGET,
        work_dir=WORK_DIR,
        total_trials=100,
        max_trials_per_task=32,
        num_trials_per_iter=16,
    )
    print("MetaSchedule tuning finished.")
    with database:
        with tvm.transform.PassContext(opt_level=3):
            lib = relay.build(mod, target=TRUSTCORE_NX_TARGET, params=params)
    lib_path = "terra_fusion_rvv_optimized.tar"
    lib.export_library(lib_path)
    print(f"[OK] Exported RVV-optimized library to {lib_path}")

if __name__ == "__main__":
    optimize_terra_rvv()
