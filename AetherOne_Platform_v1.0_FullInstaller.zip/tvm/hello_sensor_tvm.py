#!/usr/bin/env python3
"""Aether One – Hello Sensor TVM Demo (Raspberry Pi 5)"""
import time
import numpy as np
import tvm
from tvm import runtime

MODEL_LIB = "model_arm.so"
MODEL_GRAPH = "model_graph.json"
MODEL_PARAMS = "model_params.bin"

print("[INFO] Loading TVM model...")
lib = tvm.runtime.load_module(MODEL_LIB)
with open(MODEL_GRAPH) as f:
    graph = f.read()
with open(MODEL_PARAMS, "rb") as f:
    params_data = f.read()

dev = tvm.cpu(0)
mod = runtime.create(graph, lib, dev)
mod.load_params(params_data)

def read_sensors():
    return np.array([[3.4, 120.0, 15.0, 20.0]], dtype="float32")

print("[INFO] Starting inference loop (Ctrl+C to stop)...")
while True:
    try:
        x = read_sensors()
        mod.set_input("input", tvm.nd.array(x, dev))
        mod.run()
        out = mod.get_output(0).asnumpy()
        print(f"[DATA] input={x.flatten()} -> output={out.flatten()}")
        time.sleep(1.0)
    except KeyboardInterrupt:
        print("\n[STOP] Interrupted by user.")
        break
