#!/bin/bash
set -e
echo "=== Aether One™ Platform Installer v1.0 (Raspberry Pi 5) ==="

INSTALL_DIR="/opt/aetherone"
LOGFILE="/var/log/aether_install.log"
exec > >(tee -a "$LOGFILE") 2>&1

echo "[*] Updating apt and installing base packages..."
sudo apt update
sudo apt install -y git cmake ninja-build build-essential python3-venv python3-pip libssl-dev mosquitto

echo "[*] Creating install directory at $INSTALL_DIR"
sudo mkdir -p "$INSTALL_DIR"
sudo cp -r . "$INSTALL_DIR"
cd "$INSTALL_DIR"

echo "[*] Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install numpy paho-mqtt

echo "[*] Installing TVM (this may take a while)."
# NOTE: For production you may prefer prebuilt wheels or custom build.
pip install tvm

echo "[*] Configuring RVV RISC-V toolchain..."
bash configure_rvv_toolchain.sh

echo "[*] Running RVV self-test..."
bash run_rvv_selftest.sh

echo "[*] Installing liboqs and PQC Python bindings..."
bash pqc/install_liboqs.sh

echo "[*] Enabling and starting Mosquitto MQTT broker..."
sudo systemctl enable mosquitto
sudo systemctl start mosquitto

echo "[*] Verifying PQC integration..."
bash verify_pqc.sh || echo "[WARN] PQC verification reported issues, check log at $LOGFILE"

echo "[*] Running post-install PQC benchmark..."
bash run_postinstall_benchmark.sh || echo "[WARN] Benchmark issues, see /var/log/aether_pqc_benchmark.log"

echo
echo "=== Aether One Platform v1.0 installation complete ==="
echo "See docs/ for PDF documentation and /var/log/aether_pqc_benchmark.json for PQC metrics."
