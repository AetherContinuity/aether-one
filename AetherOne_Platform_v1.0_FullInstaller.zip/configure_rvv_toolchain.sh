#!/bin/bash
set -e
echo "=== Configuring RVV-enabled RISC-V GNU Toolchain (host: Raspberry Pi) ==="
TOOLCHAIN_ROOT="$HOME/riscv/toolchain"
INSTALL_PREFIX="$TOOLCHAIN_ROOT/install"

mkdir -p "$TOOLCHAIN_ROOT"
cd "$TOOLCHAIN_ROOT"

if [ ! -d riscv-gnu-toolchain ]; then
  git clone --recursive https://github.com/riscv-collab/riscv-gnu-toolchain
fi
cd riscv-gnu-toolchain
mkdir -p build && cd build

echo "[*] Running configure for rv64gcv (RVV 1.0) target..."
../configure --prefix="$INSTALL_PREFIX" --with-arch=rv64gcv --with-abi=lp64d --enable-multilib

echo "[*] Building toolchain (this will take a long time)..."
make -j$(nproc) linux

if ! grep -q "$INSTALL_PREFIX/bin" "$HOME/.bashrc"; then
  echo "export PATH=\"$INSTALL_PREFIX/bin:$PATH\"" >> "$HOME/.bashrc"
fi

echo "=== RVV RISC-V toolchain completed and installed to $INSTALL_PREFIX ==="
