import paho.mqtt.client as mqtt
import json
import time
import numpy as np

MQTT_BROKER = "localhost"
MQTT_PORT = 1883
TERRA_MQTT_TOPIC = "aetherone/telemetry/terra/fusion_output"

def simulate_terra_inference():
    tvm_output = np.array([
        0.95,
        160.0,
        65.0,
        0.003
    ], dtype=np.float32)
    payload = {
        "timestamp": int(time.time()),
        "agent_id": "TERRA_v1.2",
        "anomaly_prob": round(float(tvm_output[0]), 4),
        "data": {
            "lidar_distance": float(tvm_output[1]),
            "lidar_angle": float(tvm_output[2]),
            "radiation_level": float(tvm_output[3])
        }
    }
    return json.dumps(payload)

def terra_publish_loop():
    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1, "TERRA_Agent_Publisher")
    client.connect(MQTT_BROKER, MQTT_PORT, 60)
    print("TERRA agent started. Publishing simulated TVM outputs...")
    while True:
        try:
            message = simulate_terra_inference()
            result = client.publish(TERRA_MQTT_TOPIC, message, qos=1)
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                print(f"[MQTT] Published to {TERRA_MQTT_TOPIC}: {message}")
            else:
                print(f"[MQTT] Publish failed with rc={result.rc}")
            time.sleep(5)
        except KeyboardInterrupt:
            print("\n[STOP] TERRA agent stopped.")
            break
        except Exception as e:
            print(f"[ERROR] TERRA agent: {e}")
            time.sleep(10)

if __name__ == "__main__":
    terra_publish_loop()
