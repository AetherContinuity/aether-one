#!/bin/bash
set -e
echo "=== Verifying PQC integration (OpenSSL + liboqs) ==="
source venv/bin/activate

echo "[*] OpenSSL providers:"
openssl list -providers || true

echo "[*] Running liboqs Python test (if available)..."
if python3 -c "import oqs" 2>/dev/null; then
  python3 pqc/pqc_test.py || true
else
  echo "[WARN] liboqs-python not available in venv."
fi

echo "=== PQC verification step completed ==="
