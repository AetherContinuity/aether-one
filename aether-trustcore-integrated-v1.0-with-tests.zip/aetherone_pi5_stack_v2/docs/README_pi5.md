# Aether One Pi5 Stack v2

Tämä on demonstraatiopaketti Raspberry Pi 5 -laitteelle.
Se ei ole tuotantokäyttöön, vaan arkkitehtuurin ja LR/KRI-logiikan
nopeaan kokeiluun.

## Vaatimukset

- Raspberry Pi 5 (Bookworm / Debian-pohjainen Linux)
- Python 3.11+
- `pip` ja `venv`

## Asennus

```bash
unzip aetherone_pi5_stack_v2.zip
cd aetherone_pi5_stack_v2

python3 -m venv .venv
source .venv/bin/activate

pip install -r requirements.txt

python -m core.aether_relay
```

Tämän jälkeen avaa selaimessa:

```
http://<pi_ip>:8080/ui/
```

Näet live-telemetrian (mock-sensorit) ja LR/KRI-arvot.

## TrustCore v0.1 – attestation

Tämä paketti sisältää TrustCore v0.1 -integraation:

- Laite generoi PQC-avaimet (Dilithium3) hakemistoon `trustcore_keys/` ensimmäisellä käynnistyksellä.
- Jos TPM2 ja `tpm2-tools` ovat saatavilla, client liittää mukaan PCR-arvot + TPM-quote.
- FastAPI-demon UI näyttää viimeisimmän attestaatio-statuksen.

### 1) Käynnistä attestaatio-palvelin (erillinen terminaali)

```bash
cd aetherone_pi5_stack_v2
source .venv/bin/activate

python -m core.trustcore.server
```

Palvelin kuuntelee oletuksena portissa 5000:

- `GET /nonce`
- `POST /verify`

Ensimmäisellä kerralla palvelin "enrollaa" laitteen automaattisesti (first-seen). Tämä on demon oletus.

### 2) Käynnistä Pi5 stack

```bash
python -m core.aether_relay
```

### 3) UI

```text
http://<pi_ip>:8080/ui/
```

Kun attestaatio onnistuu, UI:ssa näkyy `PASS`.

### Ympäristömuuttujat

Pi5 stack (prefix `AETHER_`):

- `AETHER_ATTESTATION_ENABLED` (true/false)
- `AETHER_ATTESTATION_INTERVAL` (seconds)
- `AETHER_ATTESTATION_SERVER_URL` (default http://localhost:5000)
- `AETHER_ATTESTATION_POLICY_ID` (default policy_demo)

Server:

- `TRUSTCORE_PORT` (default 5000)
- `TRUSTCORE_ALLOW_FIRST_SEEN` (default 1)
- `TRUSTCORE_DATA_DIR` (default .trustcore_server)

## Huomioita

- `drivers/*`-moduulit ovat tässä vaiheessa paikkamerkkejä.
- `drivers.mock_sensors` tuottaa satunnaisia arvoja testikäyttöön.
- Todellista laiteintegraatiota varten BLE-, LiDAR-, VOC- ja Geiger-ajurit
  pitää toteuttaa raudan mukaan.

## TrustCore v1.0 – deterministic C core (native)

This integrated package adds **TrustCore v1.0** as a deterministic, platform-agnostic C core used via `ctypes`.

### Build the native library

Before running the stack, compile the shared library:

```bash
cd aetherone_pi5_stack_v2
./core/trustcore_native/build.sh
```

This produces:

- `core/trustcore_native/libtrustcore.so`

### What changes

- `/kri` now returns TrustCore v1.0 values (`kri`, `constructive`, `deltas`).
- `/lr` includes a `decision_hash` (stable SHA-256 over the decision payload).
- TrustCore v0.1 attestation signs and submits the `decision_hash` when available.

### Quick end-to-end demo

Terminal 1 (attestation server):

```bash
python -m core.trustcore.server
```

Terminal 2 (Pi5 stack):

```bash
python -m core.aether_relay
```

Open:

```text
http://<pi_ip>:8080/ui/
```
