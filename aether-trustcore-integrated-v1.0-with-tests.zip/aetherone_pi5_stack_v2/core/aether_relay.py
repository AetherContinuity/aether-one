import asyncio
import hashlib
import json
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Dict, Any, Optional

from .config import settings
from .lr_core import lr_evaluate
from .kri_engine import compute_kri
from .trustcore.client import TrustCoreClient, TrustCoreConfig
from drivers.mock_sensors import get_mock_state
from ui.web_ui import router as ui_router

app = FastAPI(title=settings.app_name)
app.include_router(ui_router, prefix="/ui", tags=["ui"])


class SensorState(BaseModel):
    voc_ppb: float = 0.0
    geiger_cpm: float = 0.0
    lidar_obstacles: int = 0


# Simple in-memory caches for demo
SENSOR_CACHE: Dict[str, Any] = {
    "voc_ppb": 0.0,
    "geiger_cpm": 0.0,
    "lidar_obstacles": 0,
    "attestation_status": "UNKNOWN",
    "attestation_timestamp": None,
}

LAST_DECISION: Dict[str, Any] = {
    "status": "UNKNOWN",
    "score": 0.0,
    "details": {},
    "decision_hash": None,
}

trustcore_client: Optional[TrustCoreClient] = None


def _hash_decision(payload: Dict[str, Any]) -> str:
    """Stable SHA-256 over canonical JSON."""
    b = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(b).hexdigest()


@app.on_event("startup")
async def startup_event():
    global trustcore_client

    # Initialize TrustCore client (optional)
    try:
        trustcore_client = TrustCoreClient(
            TrustCoreConfig(
                server_url=settings.attestation_server_url,
                policy_id=settings.attestation_policy_id,
            )
        )
        print("✅ TrustCore v0.1 initialized")
    except Exception as e:
        trustcore_client = None
        print(f"⚠️  TrustCore init failed: {e}")

    asyncio.create_task(sensor_update_loop())

    if settings.attestation_enabled and trustcore_client is not None:
        asyncio.create_task(attestation_loop())


async def sensor_update_loop():
    """Update mock sensors and compute latest LR decision."""
    while True:
        state = get_mock_state()
        SENSOR_CACHE.update(state)

        # Compute decision snapshot
        lr = lr_evaluate(SENSOR_CACHE)
        decision_payload = {
            "score": lr.score,
            "status": lr.status,
            "details": lr.details,
        }
        dh = _hash_decision(decision_payload)
        LAST_DECISION.update({
            **decision_payload,
            "decision_hash": dh,
        })
        SENSOR_CACHE["decision_hash"] = dh

        await asyncio.sleep(2.0)


async def attestation_loop():
    """Periodically attest device state to remote TrustCore server."""
    while True:
        try:
            if trustcore_client is not None:
                # Include decision_hash in attestation if available
                result = await trustcore_client.attest(SENSOR_CACHE)
                SENSOR_CACHE["attestation_status"] = result.get("status", "UNKNOWN")
                SENSOR_CACHE["attestation_timestamp"] = result.get("ts")
                print(f"🔐 Attestation: {SENSOR_CACHE['attestation_status']}")
        except Exception as e:
            SENSOR_CACHE["attestation_status"] = "FAIL"
            SENSOR_CACHE["attestation_timestamp"] = None
            print(f"❌ Attestation failed: {e}")

        await asyncio.sleep(max(5, int(settings.attestation_interval)))


@app.get("/health")
async def health():
    return {"status": "ok", "app": settings.app_name}


@app.get("/sensors", response_model=SensorState)
async def read_sensors():
    return SensorState(**SENSOR_CACHE)


@app.get("/lr")
async def lr_status():
    return {
        "score": float(LAST_DECISION.get("score", 0.0)),
        "status": LAST_DECISION.get("status", "UNKNOWN"),
        "details": LAST_DECISION.get("details", {}),
        "decision_hash": LAST_DECISION.get("decision_hash"),
    }


@app.get("/decision")
async def decision_status():
    """Explicit endpoint for last decision + hash."""
    return LAST_DECISION


@app.get("/kri")
async def kri_status():
    kri = compute_kri(SENSOR_CACHE)
    return {
        "R": kri.R,
        "S": kri.S,
        "E": kri.E,
        "kri": kri.kri,
        "constructive": kri.constructive,
        "deltas": kri.deltas,
    }


@app.get("/attestation")
async def attestation_status():
    return {
        "status": SENSOR_CACHE.get("attestation_status", "UNKNOWN"),
        "timestamp": SENSOR_CACHE.get("attestation_timestamp"),
        "device_id": trustcore_client.pqc.get_device_id() if trustcore_client else None,
        "tpm_available": trustcore_client.tpm_available if trustcore_client else False,
        "decision_hash": LAST_DECISION.get("decision_hash"),
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8080)
