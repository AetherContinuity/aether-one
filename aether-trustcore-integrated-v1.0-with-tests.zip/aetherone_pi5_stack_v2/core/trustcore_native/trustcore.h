/*
 *  Aether One AI – Kuopio Core
 *  TrustCore v1.0 – Lex Resiliens Engine
 *  -------------------------------------
 *  Tämä on alustariippumaton C-rajapinta, joka toteuttaa Lex Resiliens-säännöstön
 *  (LR-IRS, LR-RAP, LR-R, LR-E ja LR-D).
 */

#ifndef TRUSTCORE_H
#define TRUSTCORE_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    float R;
    float S;
    float E;
} lr_triplet_t;

typedef struct {
    const char *id;
    lr_triplet_t lr;
    int irs_ok;
    int rap_ok;
} agent_lr_t;

typedef struct {
    float kri_x_avg;
    float delta_R;
    float delta_S;
    float delta_E;
    int   constructive;
    int   reject;
} lr_d_result_t;

float lr_kri(const lr_triplet_t *lr);
lr_d_result_t lr_d(const agent_lr_t *agents, int count);
void trustcore_step(void);

#ifdef __cplusplus
}
#endif
#endif /* TRUSTCORE_H */
