#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="${HERE}/libtrustcore.so"

gcc -shared -fPIC -O2 \
  "${HERE}/trustcore.c" \
  "${HERE}/trustcore_wrapper.c" \
  -o "${OUT}"

echo "✅ Built: ${OUT}"
file "${OUT}" >/dev/null 2>&1 || true
