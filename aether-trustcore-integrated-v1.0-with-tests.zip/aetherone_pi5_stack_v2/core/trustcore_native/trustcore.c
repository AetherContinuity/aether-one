#include "trustcore.h"
#include <float.h>

float lr_kri(const lr_triplet_t *lr) {
    if (!lr) return 0.0f;
    return (lr->R + lr->S + lr->E) / 3.0f;
}

lr_d_result_t lr_d(const agent_lr_t *agents, int count) {
    lr_d_result_t out = (lr_d_result_t){0};
    if (!agents || count <= 0) return out;

    for (int i = 0; i < count; ++i) {
        if (!agents[i].irs_ok || !agents[i].rap_ok) {
            out.reject = 1;
            out.constructive = 0;
            return out;
        }
    }

    float minR = FLT_MAX, maxR = 0.0f;
    float minS = FLT_MAX, maxS = 0.0f;
    float minE = FLT_MAX, maxE = 0.0f;
    float kri_sum = 0.0f;

    for (int i = 0; i < count; ++i) {
        const lr_triplet_t *lr = &agents[i].lr;
        float kri = lr_kri(lr);
        kri_sum += kri;

        if (lr->R < minR) minR = lr->R;
        if (lr->R > maxR) maxR = lr->R;
        if (lr->S < minS) minS = lr->S;
        if (lr->S > maxS) maxS = lr->S;
        if (lr->E < minE) minE = lr->E;
        if (lr->E > maxE) maxE = lr->E;
    }

    out.kri_x_avg = kri_sum / (float)count;
    out.delta_R = maxR - minR;
    out.delta_S = maxS - minS;
    out.delta_E = maxE - minE;

    if (out.delta_S > 0.25f) {
        out.constructive = 0;
        out.reject = 0;
    } else {
        out.constructive = 1;
        out.reject = 0;
    }

    return out;
}

void trustcore_step(void) {
    /* Placeholder ydinloopille */
}
