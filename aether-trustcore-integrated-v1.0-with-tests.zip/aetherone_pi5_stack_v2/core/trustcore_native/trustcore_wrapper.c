#include <stdint.h>
#include <string.h>
#include "trustcore.h"

float tc_calculate_kri(float R, float S, float E) {
    lr_triplet_t lr = { R, S, E };
    return lr_kri(&lr);
}

int32_t tc_calculate_dissonance(
    float R, float S, float E,
    float* out_delta_R, float* out_delta_S, float* out_delta_E
) {
    agent_lr_t a;
    memset(&a, 0, sizeof(a));
    a.id = "pi5";
    a.lr.R = R;
    a.lr.S = S;
    a.lr.E = E;
    a.irs_ok = 1;
    a.rap_ok = 1;

    lr_d_result_t res = lr_d(&a, 1);

    if (out_delta_R) *out_delta_R = res.delta_R;
    if (out_delta_S) *out_delta_S = res.delta_S;
    if (out_delta_E) *out_delta_E = res.delta_E;

    return res.constructive ? 1 : 0;
}
