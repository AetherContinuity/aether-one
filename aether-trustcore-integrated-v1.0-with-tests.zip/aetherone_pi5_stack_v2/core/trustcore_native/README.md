# TrustCore v1.0 native library (Pi5 demo)

This folder builds the deterministic TrustCore v1.0 C core into a shared library usable from Python via `ctypes`.

## Build

```bash
./build.sh
```

Produces:
- `libtrustcore.so`

## ABI

Exports:
- `float tc_calculate_kri(float R, float S, float E)`
- `int32_t tc_calculate_dissonance(float R,float S,float E,float* dR,float* dS,float* dE)`
