#!/usr/bin/env python3
"""Lightweight performance microbenchmarks (no external deps).

Run:
  python -m tests.test_performance
"""

import os
import sys
import time
import statistics
import secrets

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.lr_core import lr_evaluate
from core.trustcore.client import TrustCoreClient, TrustCoreConfig


def _bench(name, fn, it=50):
    times = []
    for _ in range(it):
        t0 = time.perf_counter()
        fn()
        t1 = time.perf_counter()
        times.append((t1 - t0) * 1000.0)
    return {
        'name': name,
        'mean_ms': statistics.mean(times),
        'median_ms': statistics.median(times),
        'min_ms': min(times),
        'max_ms': max(times),
    }


def run(it=50):
    sensor_state = {'voc_ppb': 250.0, 'geiger_cpm': 40.0, 'lidar_obstacles': 2}

    cfg = TrustCoreConfig(server_url='http://localhost:5000', keydir='trustcore_keys_test')
    client = TrustCoreClient(cfg)
    client.tpm_available = False
    client.tpm = None

    def lr_only():
        lr_evaluate(sensor_state)

    def pqc_bundle():
        nonce = secrets.token_bytes(32)
        s = dict(sensor_state)
        s['decision_hash'] = secrets.token_bytes(32).hex()
        client.create_attestation_bundle(nonce, s)

    rows = [
        _bench('LR evaluate', lr_only, it=it),
        _bench('PQC bundle', pqc_bundle, it=it),
    ]

    print(f"Performance (iterations={it})")
    print(f"{'Component':<16} {'mean(ms)':>10} {'median':>10} {'min':>10} {'max':>10}")
    print('-' * 60)
    for r in rows:
        print(f"{r['name']:<16} {r['mean_ms']:>10.3f} {r['median_ms']:>10.3f} {r['min_ms']:>10.3f} {r['max_ms']:>10.3f}")


if __name__ == '__main__':
    run(it=50)
