#!/usr/bin/env python3
"""Unit tests for TrustCore v1.0 native C core via ctypes.

Run:
  python -m tests.test_trustcore_native
"""

import os
import sys
from pathlib import Path

# Ensure project root on path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from core.trustcore_adapter import TrustCoreNative


def _lib_path() -> str:
    p = Path(__file__).resolve().parent.parent / 'core' / 'trustcore_native' / 'libtrustcore.so'
    return str(p)


def test_kri_known_vectors() -> None:
    tc = TrustCoreNative(_lib_path())

    # These vectors match the current reference implementation shipped in this bundle.
    vectors = [
        (0.8, 0.1, 0.1, 1.0 / 3.0),
        (0.2, 0.6, 0.2, 1.0 / 3.0),
        (0.5, 0.3, 0.2, 1.0 / 3.0),
        (0.5, 0.5, 0.5, 0.5),
    ]

    for R, S, E, expected in vectors:
        got = float(tc.kri(R, S, E))
        assert abs(got - expected) < 1e-3, f'KRI mismatch for {(R,S,E)}: {got} != {expected}'


def test_dissonance_shape() -> None:
    tc = TrustCoreNative(_lib_path())
    res = tc.dissonance(0.5, 0.5, 0.5)
    assert isinstance(res, dict)
    assert 'constructive' in res
    assert 'delta_R' in res and 'delta_S' in res and 'delta_E' in res


if __name__ == '__main__':
    test_kri_known_vectors()
    test_dissonance_shape()
    print('✅ test_trustcore_native: PASS')
