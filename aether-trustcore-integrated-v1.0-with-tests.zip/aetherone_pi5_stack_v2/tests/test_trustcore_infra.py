#!/usr/bin/env python3
"""Unit/functional tests for TrustCore v0.1 infra (PQC bundle + server verify) without real TPM.

Run:
  python -m tests.test_trustcore_infra
"""

import os
import sys
import secrets

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import cbor2

from core.trustcore.client import TrustCoreClient, TrustCoreConfig
from core.trustcore.server import APP
from fastapi.testclient import TestClient


def test_attestation_flow_no_tpm() -> None:
    # Use TestClient against the in-process FastAPI app.
    with TestClient(APP) as tc:
        cfg = TrustCoreConfig(server_url='http://testserver', keydir='trustcore_keys_test')
        client = TrustCoreClient(cfg)
        client.tpm_available = False
        client.tpm = None

        sensor_state = {
            'voc_ppb': 120.0,
            'geiger_cpm': 15.0,
            'lidar_obstacles': 0,
            # include a decision hash (hex) to exercise the decision_hash path
            'decision_hash': secrets.token_bytes(32).hex(),
        }

        nonce_hex = tc.get('/nonce').json()['nonce']
        nonce = bytes.fromhex(nonce_hex)

        bundle_bytes = client.create_attestation_bundle(nonce, sensor_state)
        bundle = cbor2.loads(bundle_bytes)

        assert bundle.get('device_id')
        assert bundle.get('pqc') and bundle['pqc'].get('signature')

        resp = tc.post('/verify', content=bundle_bytes, headers={'Content-Type': 'application/cbor'})
        assert resp.status_code == 200
        data = resp.json()
        assert data['status'] == 'PASS', data


if __name__ == '__main__':
    test_attestation_flow_no_tpm()
    print('✅ test_trustcore_infra: PASS')
