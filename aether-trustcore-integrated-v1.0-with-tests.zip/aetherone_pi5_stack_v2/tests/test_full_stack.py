#!/usr/bin/env python3
"""Integration test: sensors -> LR -> decision_hash -> PQC bundle -> server verify.

Run:
  python -m tests.test_full_stack
"""

import os
import sys
import hashlib
import json

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi.testclient import TestClient

from core.lr_core import lr_evaluate
from core.trustcore.client import TrustCoreClient, TrustCoreConfig
from core.trustcore.server import APP


def _decision_hash(lr_result) -> str:
    # Canonical hash for demo: hash selected fields.
    payload = {
        'score': lr_result.score,
        'status': lr_result.status,
        'details': lr_result.details,
    }
    blob = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(blob).hexdigest()


def test_pipeline() -> None:
    scenarios = [
        {'voc_ppb': 120.0, 'geiger_cpm': 15.0, 'lidar_obstacles': 0},
        {'voc_ppb': 450.0, 'geiger_cpm': 20.0, 'lidar_obstacles': 1},
        {'voc_ppb': 80.0, 'geiger_cpm': 65.0, 'lidar_obstacles': 0},
        {'voc_ppb': 200.0, 'geiger_cpm': 30.0, 'lidar_obstacles': 3},
        {'voc_ppb': 550.0, 'geiger_cpm': 75.0, 'lidar_obstacles': 2},
    ]

    with TestClient(APP) as tc:
        cfg = TrustCoreConfig(server_url='http://testserver', keydir='trustcore_keys_test')
        client = TrustCoreClient(cfg)
        client.tpm_available = False
        client.tpm = None

        for s in scenarios:
            lr = lr_evaluate(s)
            dh = _decision_hash(lr)
            s2 = dict(s)
            s2['decision_hash'] = dh

            nonce_hex = tc.get('/nonce').json()['nonce']
            nonce = bytes.fromhex(nonce_hex)
            bundle = client.create_attestation_bundle(nonce, s2)

            resp = tc.post('/verify', content=bundle, headers={'Content-Type': 'application/cbor'})
            assert resp.status_code == 200
            data = resp.json()
            assert data['status'] == 'PASS', data


if __name__ == '__main__':
    test_pipeline()
    print('✅ test_full_stack: PASS')
