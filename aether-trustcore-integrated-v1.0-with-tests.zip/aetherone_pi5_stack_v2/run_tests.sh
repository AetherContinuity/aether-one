#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

echo "========================================"
echo "🔍 TrustCore integrated stack - Tests"
echo "========================================"

# Optional venv
if [ -d ".venv" ]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
fi

python -m tests.test_trustcore_native
python -m tests.test_trustcore_infra
python -m tests.test_full_stack
python -m tests.test_performance

echo "========================================"
echo "✅ All tests passed"
echo "========================================"
